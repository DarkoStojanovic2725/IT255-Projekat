export class Item {
  ime: String;
  constructor(ime: String) {
  }
}
