export class Slicice {
  id_slicice: number;
  broj_slicice: number;
  naziv_albuma: string;
  ime: string;
  slika: string;
  detalji: string;
  dodato: boolean;

  constructor(id_slicice: number,
  broj_slicice: number,
  naziv_albuma: string,
  ime: string, slika: string, detalji: string, dodato: boolean) {
  }
}
