import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-albumi',
  templateUrl: './albumi.component.html',
  styleUrls: ['./albumi.component.css']
})
export class AlbumiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
